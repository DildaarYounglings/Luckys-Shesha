import { TopNav } from "./TopNav";
//import "./categories.css";
import React from 'react';
export const Recomendations = () => {
  return (
    <React.Fragment>
         <style>
            {`
            .Dildaar-RecomendationsPage{
                display:flex;
                flex-direction: column;
                position:absolute;
                left:50%;
                top:13%;
                width:100%;
                height:fit-content;
                translate:-50% 0%;

            }
            `}
        </style>
        <TopNav/>
        <section className="Dildaar-RecomendationsPage">
            <section style={{position:"relative",display:"flex",flexDirection:"column"}}>
              <header>
                <h1 style={{translate:"50px 0px"}}>Recomendations</h1>
              </header>
              <section style={{display:"flex",flexDirection:"row",gap:"21rem"}}>
                <section style={{translate:"100px 0px",display:"flex",flexDirection:"column"}}>
                  <img src="images/steakCategory.png" alt="Steak"/>
                  <button style={{translate:"-30px 0px",width:"90px",height:"50px"}}>Steak</button>
                </section>
                <section style={{translate:"100px 0px",display:"flex",flexDirection:"column"}}>
                  <img src="images/noodlesCategory.png" alt="Steak"/>
                  <button style={{translate:"-30px 0px",width:"90px",height:"50px"}}>Noodles</button>
                </section>
                <section style={{translate:"100px 0px",display:"flex",flexDirection:"column"}}>
                  <img src="images/coffeeCategory.png" alt="Steak"/>
                  <button style={{translate:"-30px 0px",width:"90px",height:"50px"}}>Coffee</button>
                </section>
                <section style={{translate:"100px 0px",display:"flex",flexDirection:"column"}}>
                  <img src="images/steakCategory.png" alt="Steak"/>
                  <button style={{translate:"-30px 0px",width:"90px",height:"50px"}}>Lasagna</button>
                </section>
              </section>
            </section>
            <h1 style={{position:"relative",translate:"50px 0px",marginTop:"100px",marginBottom:"100px"}}>Popular Recipes</h1>
            <section style={{display:"grid",gridTemplateColumns:"auto auto auto"}}>
              <div style={{marginBottom:"100px",position:"relative",translate:"200px 0px",display:"flex",flexDirection:"column",width:"350px",height:"350px"}}>
                <img style={{position:"absolute",borderRadius:"10%",height:"100%",width:"100%",}} src="images/taco.png"/>
                <button style={{position:"relative",translate:"150px 0px",backgroundColor:"green",height:"25px"}}><img style={{position:"relative",translate:"11px -16px",height:"20px",width:"20px",}} src="images/bookmarkFeature.png"/></button>
                <button style={{position:"relative",translate:"-135px 230px",backgroundColor:"green",width:"150px",height:"30px"}}><img style={{position:"relative",translate:"60px -15px",height:"17px",width:"fit-content",}} src="images/ViewIngredientsButton.png"/></button>
              </div>
              <div style={{marginBottom:"100px",position:"relative",translate:"250px 0px",display:"flex",flexDirection:"column",width:"350px",height:"350px"}}>
                <img style={{position:"absolute",borderRadius:"10%",height:"100%",width:"100%",}} src="images/pancake.png"/>
                <button style={{position:"relative",translate:"150px 0px",backgroundColor:"green",height:"25px"}}><img style={{position:"relative",translate:"11px -16px",height:"20px",width:"20px",}} src="images/bookmarkFeature.png"/></button>
                <button style={{position:"relative",translate:"-135px 230px",backgroundColor:"green",width:"150px",height:"30px"}}><img style={{position:"relative",translate:"60px -15px",height:"17px",width:"fit-content",}} src="images/ViewIngredientsButton.png"/></button>
              </div>
              <div style={{marginBottom:"100px",position:"relative",translate:"300px 0px",display:"flex",flexDirection:"column",width:"350px",height:"350px"}}>
                <img style={{position:"absolute",borderRadius:"10%",height:"100%",width:"100%",}} src="images/fishAndSalad.png"/>
                <button style={{position:"relative",translate:"150px 0px",backgroundColor:"green",height:"25px"}}><img style={{position:"relative",translate:"11px -16px",height:"20px",width:"20px",}} src="images/bookmarkFeature.png"/></button>
                <button style={{position:"relative",translate:"-135px 230px",backgroundColor:"green",width:"150px",height:"30px"}}><img style={{position:"relative",translate:"60px -15px",height:"17px",width:"fit-content",}} src="images/ViewIngredientsButton.png"/></button>
              </div>
              <div style={{marginBottom:"100px",position:"relative",translate:"200px 0px",display:"flex",flexDirection:"column",width:"350px",height:"350px"}}>
                <img style={{position:"absolute",borderRadius:"10%",height:"100%",width:"100%",}} src="images/noodlesDish.png"/>
                <button style={{position:"relative",translate:"150px 0px",backgroundColor:"green",height:"25px"}}><img style={{position:"relative",translate:"11px -16px",height:"20px",width:"20px",}} src="images/bookmarkFeature.png"/></button>
                <button style={{position:"relative",translate:"-135px 230px",backgroundColor:"green",width:"150px",height:"30px"}}><img style={{position:"relative",translate:"60px -15px",height:"17px",width:"fit-content",}} src="images/ViewIngredientsButton.png"/></button>
              </div>
              <div style={{marginBottom:"100px",position:"relative",translate:"250px 0px",display:"flex",flexDirection:"column",width:"350px",height:"350px"}}>
                <img style={{position:"absolute",borderRadius:"10%",height:"100%",width:"100%",}} src="images/krisztina-papp.png"/>
                <button style={{position:"relative",translate:"150px 0px",backgroundColor:"green",height:"25px"}}><img style={{position:"relative",translate:"11px -16px",height:"20px",width:"20px",}} src="images/bookmarkFeature.png"/></button>
                <button style={{position:"relative",translate:"-135px 230px",backgroundColor:"green",width:"150px",height:"30px"}}><img style={{position:"relative",translate:"60px -15px",height:"17px",width:"fit-content",}} src="images/ViewIngredientsButton.png"/></button>
              </div>
              <div style={{marginBottom:"100px",position:"relative",translate:"300px 0px",display:"flex",flexDirection:"column",width:"350px",height:"350px"}}>
                <img style={{position:"absolute",borderRadius:"10%",height:"100%",width:"100%",}} src="images/soup.png"/>
                <button style={{position:"relative",translate:"150px 0px",backgroundColor:"green",height:"25px"}}><img style={{position:"relative",translate:"11px -16px",height:"20px",width:"20px",}} src="images/bookmarkFeature.png"/></button>
                <button style={{position:"relative",translate:"-135px 230px",backgroundColor:"green",width:"150px",height:"30px"}}><img style={{position:"relative",translate:"60px -15px",height:"17px",width:"fit-content",}} src="images/ViewIngredientsButton.png"/></button>
              </div>
              <div style={{marginBottom:"100px",position:"relative",translate:"200px 0px",display:"flex",flexDirection:"column",width:"350px",height:"350px"}}>
                <img style={{position:"absolute",borderRadius:"10%",height:"100%",width:"100%",}} src="images/keesch.png"/>
                <button style={{position:"relative",translate:"150px 0px",backgroundColor:"green",height:"25px"}}><img style={{position:"relative",translate:"11px -16px",height:"20px",width:"20px",}} src="images/bookmarkFeature.png"/></button>
                <button style={{position:"relative",translate:"-135px 230px",backgroundColor:"green",width:"150px",height:"30px"}}><img style={{position:"relative",translate:"60px -15px",height:"17px",width:"fit-content",}} src="images/ViewIngredientsButton.png"/></button>
              </div>
              <div style={{marginBottom:"100px",position:"relative",translate:"250px 0px",display:"flex",flexDirection:"column",width:"350px",height:"350px"}}>
                <img style={{position:"absolute",borderRadius:"10%",height:"100%",width:"100%",}} src="images/eggAndSteak.png"/>
                <button style={{position:"relative",translate:"150px 0px",backgroundColor:"green",height:"25px"}}><img style={{position:"relative",translate:"11px -16px",height:"20px",width:"20px",}} src="images/bookmarkFeature.png"/></button>
                <button style={{position:"relative",translate:"-135px 230px",backgroundColor:"green",width:"150px",height:"30px"}}><img style={{position:"relative",translate:"60px -15px",height:"17px",width:"fit-content",}} src="images/ViewIngredientsButton.png"/></button>
              </div>
              <div style={{marginBottom:"100px",position:"relative",translate:"300px 0px",display:"flex",flexDirection:"column",width:"350px",height:"350px"}}>
                <img style={{position:"absolute",borderRadius:"10%",height:"100%",width:"100%",}} src="images/giantMuffin.png"/>
                <button style={{position:"relative",translate:"150px 0px",backgroundColor:"green",height:"25px"}}><img style={{position:"relative",translate:"11px -16px",height:"20px",width:"20px",}} src="images/bookmarkFeature.png"/></button>
                <button style={{position:"relative",translate:"-135px 230px",backgroundColor:"green",width:"150px",height:"30px"}}><img style={{position:"relative",translate:"60px -15px",height:"17px",width:"fit-content",}} src="images/ViewIngredientsButton.png"/></button>
              </div>
            </section>
        </section>
    </React.Fragment>
  )
}
