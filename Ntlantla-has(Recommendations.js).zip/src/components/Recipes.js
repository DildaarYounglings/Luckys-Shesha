import {React,useRef} from 'react';
import { TopNav } from '../components/TopNav';
import {NavLink} from 'react-router-dom';

const API_KEY = "d4397e4cb74f4ebca3d4eb9e7d2ea680";



export const Recipes = ({API_KEY,query,setQuery,recipes,setRecipes,isDoneLoading,setIsDoneLoading}) => {
    //main variables
    const API_URL_normal = `https://api.spoonacular.com/recipes/complexSearch?query=pasta&maxFat=25&number=2/information?apiKey=0d226b2d19b6426dad13000aac1c2c16&includeNutrition=true`;
    let ApiUrl_searchFeature =`https://api.spoonacular.com/recipes/complexSearch?query=${query}&number=${75}&apiKey=${API_KEY}&includeNutrition=true`
    const videoEl = useRef();

    const handleSearch = async(e) => {
        e.preventDefault();videoEl.current.play();setIsDoneLoading("loading");
        let myTimeout = setTimeout(() => {
            setIsDoneLoading("");
            clearTimeout(myTimeout);
        }, 2000);
        //const recipeData = await fetch(`https://api.spoonacular.com/recipes/complexSearch?query=${query}&number=${9}&apiKey=${API_KEY}&includeNutrition=true`).then( response => response.json() ).then( jsonData => jsonData.results);
        //setRecipes(recipeData);
        //setQuery("");
        //console.log(recipeData);
    }
  return (<>
    <style>
        {`/*start of Recipe.js*/
  .Recipes{
    display: flex;
  }
  .RecipeSearchBar{
    position:relative;
    z-index:1;
    translate:415px -0px;
    border-radius:10%;
    width:60rem;
    height:2rem;
    margin-top:50px
  }
  .RecipeSearchButton{
    cursor: pointer;
    position:relative;z-index:1;
    right:0;translate:1210px 70px;
    border-radius:20%;
    margin-left:1rem;
    width:4.5rem;
    height:2.5rem;
  }
  .RecipesList{
    display:grid;
    grid-template-columns: auto auto auto;
    gap:100px;
    list-style-type:none;
  }
  .RecipeListItem{
    background-color:#e2e2e2;
    width:500px;
    border-radius:10%;
  }
  .RecipeListImg{
    background-color:#e2e2e2;
  }
  .LoadingScreen{
    width:100%;
    height:100vh;
    transition-duration:5000ms;
  }
  
  .LoadingScreen{
    background-color:black;
    width:100%;
    height:75vh;
    transition-duration:5000ms;
  }
  .DisplayNone{
    display:none;
  }
  /*end of Recipe.js*/`}
    </style>
    <TopNav/>
    <section className={`Recipes`}>
        <form style={{marginBottom:"60px",border:"none"}} onSubmit={(e)=>handleSearch(e)}>
            <input
            className={`RecipeSearchBar`} 
            type="text" 
            value={query}
            onChange={(e) => {console.log(e.target.value);setQuery(e.target.value);}}/>
            <button className={`RecipeSearchButton`} type="submit">search</button>
        </form>
        <div style={{position:"relative",width:"100%",right:"0",translate:"100px 200px"}} className={`${(isDoneLoading === "loading")? "LoadingScreen" : "DisplayNone"}`}>
            <video ref={videoEl} src={`loading.mp4`} loop="true" className={`${(isDoneLoading === "loading")? "LoadingScreen" : "DisplayNone"}`}/>
        </div>
        <div className={`RecipesContainer`}>
            <ul className={`RecipesList`}>
                {recipes && recipes.map((item)=>(
                <li className={`RecipeListItem`} key={item.id}>
                    <img className={`RecipeListImg`} src={item.image} alt={item.title}/>
                    <h3>{item.title}</h3><NavLink to={`/recipesMethods/${item.title}`} style={{textDecoration:"none",color:"black"}}>click to view method</NavLink>
                </li>
            ))}
            </ul>
        </div>
    </section>
  </>)
}