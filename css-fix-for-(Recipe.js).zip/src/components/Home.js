import React, { useRef } from 'react';
import { TopNav } from './TopNav';
import { NavLink } from 'react-router-dom';



export const Home = () => {
  const recipeElRef = useRef();
  const pancakeIngredientsEl = useRef();
  return (<>
  <style>
    {`
    /*begining of all css for Home.js page*/
    body{
      overflow-x: hidden;
    }
    .home_header1{
      width:100%;
      position: relative;
      right:-100px;
      display: flex;
      margin-top:100px;
      margin-left:auto;
      margin-right: auto;
      margin-bottom:30vh;
    }

    .home_header2{
      width: 100%;
      position: relative;
      right:-100px;bottom:-70px;
      display: flex;gap:40vh;
      margin-left: auto;
      margin-right: auto;
      margin-bottom:20vh;
    }
    .home_header_left{
      width:auto;height:auto;
      margin-top: 25px;
      animation: FromRight2left ease-in-out 2s;
    }
    .homeHeaderLeft_H2{
      text-Align:left;
      font-weight:initial;
      margin-left:90px;
      font-size:x-large;
      animation: FromRight2Left ease-in-out 2s;
    }
    .homeHeaderLeft_p3{
      position: relative;
      top: 20px;
      left: -13%;
      font-weight:initial;
      margin-left:90px;
      font-size: x-large;
      animation: FromRight2Left ease-in-out 2s;
    }
    .homeHeaderLeft_Button{
      position: relative;
      top: -70px;
      left: 10%;
      border-radius:37px;
      border:none;
      height:42px;
      width:160px;
      background-color:#36873E;
      color:white;
      
    }
    .homeHeaderLeft_Button:hover{
      cursor: pointer;
      border-radius:37px;
      border:none;height:42px;
      width:160px;
      background-color:#36873E;
      color:white;
      margin-bottom:190px
    }
    .home_footer{
      width: max-content;
      display:flex;
      flex-direction: row;
      position:relative;left:10rem;
      gap:30rem;
    }

    .home_header_right{
      height:67vh;
      width: fit-content;
      animation: FromLeft2Right ease-in-out 2s;
    }



    @keyframes FromLeft2Right{
      from{transform:translateX(200%);}
      to{transform:translateX(0px);}
    }
    @keyframes FromRight2left{
      from{transform:translateX(-200%);}
      to{transform:translateX(0px);}
    }
    @keyframes FromOppacity1-ToOppacity0{
      from{opacity:1;}
      to{opacity:0;}
    }
    @keyframes FromOppacity0-ToOppacity1{
      from{opacity:0;}
      to{opacity:1;}
    }

    .homeFooter_div1{
      display: flex;flex-direction: column; width:max-content;height: fit-content;
      animation:FromRight2left ease-in-out 3s;
    }
    .homeFooter_div2{
      display: flex;flex-direction: column;width:max-content;height: fit-content;
      animation: FromOppacity0-ToOppacity1 ease-in-out 5s;
    }
    .homeFooter_div3{
      display: flex;flex-direction: column; width:max-content;height: fit-content;
      animation:FromLeft2Right ease-in-out 3s;
    }
    /*end of all css for Home.js page*/
    `}
  </style>
  <section>
      <TopNav />
        <div className='home_header1'>

          <div className='home_header_left' style={{marginRight:"auto"}}>
            <h1>Life is uncertain. Eat  first</h1>
            <p className="homeHeaderLeft_p3"> “ A recipe has no soul.<br />You as the cook must bring soul to the recipe”<br /><b>-Thomas Keller</b> </p>


            <img src="images/swirlyArrow.png" style={{ position: "relative", left: "10%", top: "-50px" }}></img><br />
            <button className="homeHeaderLeft_Button" onClick={function () { recipeElRef.current.click() }}>Explore Recipes <NavLink ref={recipeElRef} to="/recipes" hidden /></button>
          </div>

          <div className='home_header_right' >
            <img src={`images/homeHeaderRight.png`} style={{position:"relative", height: "100%", width: "40rem", }} alt='' />
          </div>

        </div>

        <div className='home_header2'>

          <div className='home_header_right'>
            <img src={`images/homeHeader2.png`} style={{ position: "relative", left: "0%", height: "80%", width: "100%", top:"-140px", }} alt='' />
          </div>

          <div className='home_header_left'>
            <h1 style={{ position: "relative", left: "0%", top:"-140px", }}>Create your own Recipe</h1>
            <h3 className="homeHeaderLeft_H3" style={{ position: "relative", left: "18%", top: "-90px", }}>
              Using the ingredients you have we can help you<br/> make a meal<br /><br />Porem ipsum dolor sit amet, consectetur<br/> adipiscing elit. Nunc vulputate libero et velit<br/> interdum, ac aliquet odio mattis.
            </h3>
          </div>
        </div>

        <div style={{ marginTop:"20vh",width: "fit-content" }}>
          <h1 style={{ position: "relative", marginBottom:"5rem",marginLeft:"2rem"}}>Trending recipes for the month</h1>

          <div className="home_footer">
            <div className="homeFooter_div1">
              <div style={{ position: "relative",width:"auto",height:"auto"}} >
                <button style={{ cursor: 'pointer', position: "absolute", backgroundColor: "green",right:"0",translate:"129px -10px",zIndex:"1",height:"fit-content"}}><img style={{width:"15px", height:"20px",position:"relative",translate:"9px -17px"}} src={`images/bookmarkFeature.png`} alt='' /></button>
                <img src={`images/pancake.png`} alt='' />
                <button style={{ cursor: 'pointer', position: "absolute", backgroundColor: "green", left: "0", bottom: "0",translate:"-110px 155px",height:"fit-content",width:"fit-content"}} onClick={function () { pancakeIngredientsEl.current.click(); }}><img style={{position:"relative",translate:"50px -15px"}} src={`images/ViewIngredientsButton.png`} alt='' /><NavLink ref={pancakeIngredientsEl} to="/recipesMethods/Pancakes" hidden /></button>
              </div>
              <div>
                <h2 className="homeHeaderLeft_h2">Pancake</h2>
                <div><img src={`images/gordonRamsy.png`} alt='' /><h4>Gordon Ramsay</h4></div>
              </div>
            </div>

            <div className="homeFooter_div2">
              <div style={{ position: "relative" }} >
                <button style={{ cursor: 'pointer', position: "absolute", backgroundColor: "green",right:"0",translate:"118px -10px",zIndex:"1",height:"fit-content"}}><img style={{width:"15px", height:"20px",position:"relative",translate:"9px -17px"}} src={`images/bookmarkFeature.png`} alt='' /></button>
                <img src={`images/friedChickenAndRice.png`} alt='' />
                <button style={{ cursor: 'pointer', position: "absolute", backgroundColor: "green", left: "0", bottom: "0",translate:"-120px 155px",height:"fit-content",width:"fit-content"}} onClick={function () { pancakeIngredientsEl.current.click(); }}><img style={{position:"relative",translate:"50px -15px"}} src={`images/ViewIngredientsButton.png`} alt='' /><NavLink ref={pancakeIngredientsEl} to="/recipesMethods/Pancakes" hidden /></button>
              </div>
              <div>
                <h2 className="homeHeaderLeft_h2">Fried Chicken & Rice</h2>
                <div><img src={`images/pierreGagnaire.png`} alt='' /><h4>Pierre Gagnaire</h4></div>
              </div>
            </div>

            <div className="homeFooter_div3">
              <div style={{ position: "relative"}} >
                <button style={{ cursor: 'pointer', position: "absolute", backgroundColor: "green",right:"0",translate:"130px -10px",zIndex:"1",height:"fit-content"}}><img style={{width:"15px", height:"20px",position:"relative",translate:"9px -17px"}} src={`images/bookmarkFeature.png`} alt='' /></button>
                <img src={`images/burger.png`} alt='' />
                <button style={{ cursor: 'pointer', position: "absolute", backgroundColor: "green", left: "0", bottom: "0",translate:"-110px 155px",height:"fit-content",width:"fit-content"}} onClick={function () { pancakeIngredientsEl.current.click(); }}><img style={{position:"relative",translate:"50px -15px"}} src={`images/ViewIngredientsButton.png`} alt='' /><NavLink ref={pancakeIngredientsEl} to="/recipesMethods/Pancakes" hidden /></button>
              </div>
              <div>
                <h2 className="homeHeaderLeft_h2">Burger & Fries</h2>
                <div><img src={`images/gordonRamsy.png`} alt='' /><h4>Gordon Ramsay</h4></div>
              </div>
            </div>
          </div>
        </div>
    </section></>)
}
/*<div style={{ marginTop:"20vh",width: "fit-content" }}>

<h1 style={{ position: "relative", marginBottom:"5rem",marginLeft:"2rem"}}>Trending recipes for the month</h1>

<div className="home_footer">
  <div className="homeFooter_div1">
    <div style={{ position: "relative" }} >
      <button style={{ cursor: 'pointer', position: "absolute", backgroundColor: "green", right: "0" }}><img src={`images/bookmarkFeature.png`} alt='' /></button>
      <img src={`images/pancake.png`} alt='' />
      <button style={{ cursor: 'pointer', position: "absolute", backgroundColor: "green", left: "0", bottom: "0" }} onClick={function () { pancakeIngredientsEl.current.click(); }}><img src={`images/ViewIngredientsButton.png`} alt='' /><NavLink ref={pancakeIngredientsEl} to="/recipesMethods/Pancakes" hidden /></button>
    </div>
    <div>
      <h2 className="homeHeaderLeft_h2">Pancake</h2>
      <div><img src={`images/gordonRamsy.png`} alt='' /><h4>Gordon Ramsay</h4></div>
    </div>
  </div>

  <div className="homeFooter_div3" ></div>
    <div style={{ position: "relative" }} >
      <button style={{ position: "absolute", backgroundColor: "green", right: "0" }}><img src={`images/bookmarkFeature.png`} alt='' /></button>
      <button style={{ position: "absolute", backgroundColor: "green", left: "0", bottom: "0" }}><img src={`images/ViewIngredientsButton.png`} alt='' /></button>
    </div>
    <div>
      <h2 className="homeHeaderLeft_h2">Burger & Fries</h2>
      <div><img src={`images/pierreGagnaire.png`} alt='' /><h4>Pierre Gagnaire</h4></div></div>
    </div>
  </div>
  <div className="homeFooter_div2"></div>
    <div style={{ position: "relative" }} >
      <button style={{ position: "absolute", backgroundColor: "green", right: "0" }}><img src={`images/bookmarkFeature.png`} alt='' /></button>
      
      <button style={{ position: "absolute", backgroundColor: "green", left: "0", bottom: "0" }}><img src={`images/ViewIngredientsButton.png`} alt='' /></button>
    </div>
    <div>
      <h2 className="homeHeaderLeft_h2"></h2>
    </div>*/