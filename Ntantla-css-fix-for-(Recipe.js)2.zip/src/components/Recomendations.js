import { TopNav } from "./TopNav";
//import "./categories.css";
import React from 'react';
export const Recomendations = () => {
  return (
    <React.Fragment>
         <style>
            {`
            .Dildaar-RecomendationsPage{
                display:flex;
                flex-direction: column;
                position:absolute;
                left:50%;
                top:13%;
                width:100%;
                height:fit-content;
                translate:-50% 0%;
                outline:1px solid black;
            }
            `}
        </style>
        <TopNav/>
        <section className="Dildaar-RecomendationsPage">
            <section style={{display:"flex",flexDirection:"column"}}>
              <h1>Recomendations</h1>
              <section style={{display:"flex",flexDirection:"row"}}>
                <section style={{translate:"100px 0px",display:"flex",flexDirection:"column"}}><img src="images/steakCategory.png" alt="Steak"/><button>Steak</button></section>
              </section>
            </section>
        </section>
    </React.Fragment>
  )
}
